const share = require('./controller-share');

module.exports ={
	share,
};